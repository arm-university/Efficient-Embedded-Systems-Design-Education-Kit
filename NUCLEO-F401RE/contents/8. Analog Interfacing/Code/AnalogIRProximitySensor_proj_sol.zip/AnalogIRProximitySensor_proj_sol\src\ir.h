#ifndef IR_H
#define IR_H

void ir_init(void);
int ir_measure(void);

#endif // IR_H

// *******************************ARM University Program Copyright � ARM Ltd 2016*************************************   
