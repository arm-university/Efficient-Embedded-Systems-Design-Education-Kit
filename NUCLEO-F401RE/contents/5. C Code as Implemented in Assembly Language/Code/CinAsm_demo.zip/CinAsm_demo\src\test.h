#ifndef TEST_H
#define TEST_H

void test_static_auto_local_variables(void);
int test_control_structures(void);
void test_get_arrays(unsigned char n, unsigned char j);
int test_set_arrays(char a, int b, char c);
int test_call(int arg1_1);

#endif // TEST_H

// *******************************ARM University Program Copyright � ARM Ltd 2016*************************************   
