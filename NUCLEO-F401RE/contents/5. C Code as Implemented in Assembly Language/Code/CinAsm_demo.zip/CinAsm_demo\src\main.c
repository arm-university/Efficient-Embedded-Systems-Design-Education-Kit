#include "test.h"

int main(void)
{
	test_static_auto_local_variables();
	test_control_structures();
	test_get_arrays(2, 4);
	test_set_arrays(1,2000,3);
	test_call(6);
	
	while (1);
}

// *******************************ARM University Program Copyright � ARM Ltd 2016*************************************   
